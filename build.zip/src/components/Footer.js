import React from "react";


function Footer() {
  return (
    <footer className="footer">
      <p> 2024 KababJees Fried Chicken.</p>
    </footer>
  );
}

export default Footer;
