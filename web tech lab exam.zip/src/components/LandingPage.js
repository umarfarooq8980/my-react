import React from "react";


function LandingPage() {
  return (
    <div className="landing-page">
      <img src="" alt="Taste the KababJees Magic" className="" />
      <h1>Welcome to KababJees Fried Chicken</h1>
      <p>Delicious fried chicken, wings, and more!</p>
    </div>
  );
}

export default LandingPage;
