import React from "react";


function Navbar() {
  return (
    <nav className="navbar">
      <img src="images.deliveryhero.io/image/fd-pk/LH/qcve-listing.jpg" alt="KababJees Fried Chicken" />
      <ul className="nav-links">
        <li>Home</li>
        <li>Menu</li>
        <li>Order</li>
      </ul>
    </nav>
  );
}

export default Navbar;
