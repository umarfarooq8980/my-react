import React from "react";


function SpecialityMenu({ items }) {
  return (
    <div className="menu">
      <h2>Our Specialities</h2>
      <div className="menu-items">
        {items.map((item, index) => (
          <div key={index} className="menu-item">
            <img src={item.image} alt={item.name} className="menu-item-image" />
            <h3>{item.name}</h3>
            <p>{item.description}</p>
            <p className="price">{item.price}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default SpecialityMenu;
